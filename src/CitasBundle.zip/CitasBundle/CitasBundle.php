<?php

namespace CitasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CitasBundle extends Bundle
{
}
