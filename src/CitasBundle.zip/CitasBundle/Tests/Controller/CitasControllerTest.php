<?php

namespace CitasBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class CitasControllerTest extends WebTestCase
{
}
